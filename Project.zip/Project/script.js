// DOM Elements
const loginBtn = document.getElementById('login-btn');
const registerBtn = document.getElementById('register-btn');
const loginModal = document.getElementById('login-modal');
const registerModal = document.getElementById('register-modal');
const closeModalBtns = document.querySelectorAll('.close-modal');
const switchToRegister = document.getElementById('switch-to-register');
const switchToLogin = document.getElementById('switch-to-login');
const loginForm = document.getElementById('login-form');
const registerForm = document.getElementById('register-form');
const newsletterForm = document.getElementById('newsletter-form');

// Open Login Modal
loginBtn.addEventListener('click', () => {
    loginModal.style.display = 'block';
});

// Open Register Modal
registerBtn.addEventListener('click', () => {
    registerModal.style.display = 'block';
});

// Close Modals
closeModalBtns.forEach(btn => {
    btn.addEventListener('click', () => {
        loginModal.style.display = 'none';
        registerModal.style.display = 'none';
    });
});

// Switch to Register Form
switchToRegister.addEventListener('click', (e) => {
    e.preventDefault();
    loginModal.style.display = 'none';
    registerModal.style.display = 'block';
});

// Switch to Login Form
switchToLogin.addEventListener('click', (e) => {
    e.preventDefault();
    registerModal.style.display = 'none';
    loginModal.style.display = 'block';
});

// Close Modal When Clicking Outside
window.addEventListener('click', (e) => {
    if (e.target === loginModal) {
        loginModal.style.display = 'none';
    }
    if (e.target === registerModal) {
        registerModal.style.display = 'none';
    }
});

// Login Form Submission
loginForm.addEventListener('submit', (e) => {
    e.preventDefault();
    
    const email = document.getElementById('login-email').value;
    const password = document.getElementById('login-password').value;
    
    // Simple validation
    if (!email || !password) {
        alert('Please fill in all fields');
        return;
    }
    
    // In a real app, you would send this to your backend
    console.log('Login attempt with:', { email, password });
    
    // Simulate successful login
    alert('Login successful!');
    loginModal.style.display = 'none';
    
    // Update UI for logged-in user
    loginBtn.textContent = 'My Account';
    registerBtn.style.display = 'none';
});

// Register Form Submission
registerForm.addEventListener('submit', (e) => {
    e.preventDefault();
    
    const name = document.getElementById('register-name').value;
    const email = document.getElementById('register-email').value;
    const password = document.getElementById('register-password').value;
    const confirmPassword = document.getElementById('register-confirm-password').value;
    
    // Simple validation
    if (!name || !email || !password || !confirmPassword) {
        alert('Please fill in all fields');
        return;
    }
    
    if (password !== confirmPassword) {
        alert('Passwords do not match');
        return;
    }
    
    if (password.length < 6) {
        alert('Password must be at least 6 characters');
        return;
    }
    
    // In a real app, you would send this to your backend
    console.log('Registration with:', { name, email, password });
    
    // Simulate successful registration
    alert('Registration successful! You are now logged in.');
    registerModal.style.display = 'none';
    
    // Update UI for logged-in user
    loginBtn.textContent = 'My Account';
    registerBtn.style.display = 'none';
});

// Newsletter Form Submission
newsletterForm.addEventListener('submit', (e) => {
    e.preventDefault();
    const email = newsletterForm.querySelector('input').value;
    
    if (!email) {
        alert('Please enter your email address');
        return;
    }
    
    // In a real app, you would send this to your backend
    console.log('Newsletter subscription:', email);
    alert('Thank you for subscribing to our newsletter!');
    newsletterForm.reset();
});

// Cart Counter (example functionality)
const cartIcon = document.querySelector('.cart-icon');
let cartCount = 0;

// Add to cart buttons functionality
document.querySelectorAll('.btn-add-to-cart').forEach(btn => {
    btn.addEventListener('click', () => {
        cartCount++;
        cartIcon.setAttribute('data-count', cartCount);
        alert('Item added to cart!');
    });
});

// Initialize cart icon
cartIcon.setAttribute('data-count', cartCount);